import React from "react";

function NotaLegal() {
  return (
    <div
      className="border rounded p-3 mt-4 bg-light text-center small text-muted"
      style={{ fontStyle: "italic" }}
    >
      Presupuesto sujeto a modificaciones sin previo aviso
    </div>
  );
}

export default NotaLegal;
