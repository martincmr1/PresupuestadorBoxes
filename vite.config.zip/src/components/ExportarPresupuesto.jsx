import React, { useRef } from "react";
import { FaPrint, FaFilePdf } from "react-icons/fa";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import Diagnosticos from "./Diagnosticos";

import Promociones from "./Promociones";

function ExportarPresupuesto({ productos }) {
  const presupuestoRef = useRef();

  const prepararParaExportar = () => {
    document.querySelectorAll(".ocultar-al-exportar").forEach((el) => (el.style.display = "none"));
  };

  const restaurarDespuesDeExportar = () => {
    document.querySelectorAll(".ocultar-al-exportar").forEach((el) => (el.style.display = "block"));
  };

  const exportarPDF = async () => {
    prepararParaExportar();

    await new Promise((resolve) => requestAnimationFrame(resolve)); // Esperar render

    const input = presupuestoRef.current;
    const canvas = await html2canvas(input, {
      scale: 2,
      useCORS: true,
      scrollY: -window.scrollY
    });

    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgProps = pdf.getImageProperties(imgData);
    const imgHeight = (imgProps.height * pageWidth) / imgProps.width;

    if (imgHeight <= pageHeight) {
      pdf.addImage(imgData, "PNG", 0, 0, pageWidth, imgHeight);
    } else {
      let position = 0;
      let remainingHeight = imgHeight;
      while (remainingHeight > 0) {
        pdf.addImage(imgData, "PNG", 0, position, pageWidth, imgHeight);
        remainingHeight -= pageHeight;
        if (remainingHeight > 0) {
          pdf.addPage();
          position = -pageHeight + (imgHeight - remainingHeight);
        }
      }
    }

    pdf.save("Presupuesto.pdf");

    restaurarDespuesDeExportar();
  };

  const imprimirPresupuesto = () => {
    prepararParaExportar();
    setTimeout(() => {
      window.print();
      setTimeout(restaurarDespuesDeExportar, 500);
    }, 300);
  };

  const total = productos.reduce((acc, p) => acc + (p.precio * (p.cantidad || 1)), 0);
  const totalCuotas = total / 6;

  return (
    <div>
      <div className="text-end my-3 ocultar-al-exportar">
        <button className="btn btn-primary me-2" onClick={imprimirPresupuesto}>
          <FaPrint /> Imprimir
        </button>
        <button className="btn btn-danger" onClick={exportarPDF}>
          <FaFilePdf /> Exportar PDF
        </button>
      </div>

      <div ref={presupuestoRef} className="p-3 border bg-white presupuesto-print">
        <h4 className="text-center fw-bold">Presupuesto de Cambio de Aceite</h4>

        <table className="table">
          <thead>
            <tr>
              <th>Descripción</th>
              <th className="text-end">Cantidad</th>
              <th className="text-end">Subtotal</th>
            </tr>
          </thead>
          <tbody>
            {productos.map((producto, index) => (
              <tr key={index}>
                <td>{producto.descripcion}</td>
                <td className="text-end">{producto.cantidad || 1}</td>
                <td className="text-end">
                  <strong>${(producto.precio * (producto.cantidad || 1)).toFixed(2)}</strong>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <h5 className="text-end fw-bold">Total Servicio Premium: ${total.toFixed(0)}</h5>
        <h6 className="text-end text-muted">
          Total en 6 cuotas sin interés con Visa o Mastercard (Exclusivo App YPF):{" "}
          <strong>${totalCuotas.toFixed(0)} x 6</strong>
        </h6>

        <div className="mt-4 avoid-break">
          <Promociones />
          <Diagnosticos />
          <NotaLegal />
        </div>
      </div>
    </div>
  );
}

export default ExportarPresupuesto;
