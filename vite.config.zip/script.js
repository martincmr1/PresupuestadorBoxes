document.addEventListener('DOMContentLoaded', function() {
    // ...existing code...
    var element = document.getElementById('someElementId');
    if (element) {
        // Element found, proceed with your logic
        // ...existing code...
    } else {
        console.error('Element with ID "someElementId" not found.');
    }
    // ...existing code...
});
